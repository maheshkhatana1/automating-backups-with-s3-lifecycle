import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    sns = boto3.client('sns')
    
    source = os.environ.get('SOURCE_BUCKET')
    # Split the comma-separated list from Terraform
    destinations = os.environ.get('BACKUP_BUCKETS', '').split(',')
    sns_topic = os.environ.get('SNS_TOPIC_ARN')
    
    report = {"success": 0, "failures": 0, "details": []}

    try:
        paginator = s3.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=source):
            if 'Contents' not in page:
                continue
                
            for obj in page['Contents']:
                key = obj['Key']
                # Replicate to every destination bucket
                for dest in destinations:
                    try:
                        s3.copy_object(
                            CopySource={'Bucket': source, 'Key': key},
                            Bucket=dest.strip(),
                            Key=key
                        )
                        report["success"] += 1
                    except Exception as e:
                        report["failures"] += 1
                        report["details"].append(f"Failed {key} to {dest}: {str(e)}")

        status = "HEALTHY" if report["failures"] == 0 else "DEGRADED"
        msg = f"Geo-Redundant Backup {status}\nCopied: {report['success']}\nErrors: {len(report['details'])}"

    except Exception as e:
        status = "CRITICAL_FAILURE"
        msg = f"System Error: {str(e)}"

    if sns_topic:
        sns.publish(TopicArn=sns_topic, Subject=f"Backup Status: {status}", Message=msg)
    
    return {'statusCode': 200 if status != "CRITICAL_FAILURE" else 500, 'body': msg}

